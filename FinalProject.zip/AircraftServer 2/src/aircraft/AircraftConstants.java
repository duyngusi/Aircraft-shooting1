package aircraft;

public interface AircraftConstants {
  public static int SEND_HANDLE = 1;
    public static int RECORD_START_VOTE = 2;
    public static int MOVE_AIRCRAFT = 3;
    public static int GET_PLAYER_BALLS = 4;
    public static int GET_PLAYER_AIRCRAFTS = 5;
    public static int GET_BOSS_BALLS = 6;
    public static int GET_BOSS_HEALTH = 7;
    public static int GET_PLAYER_HEALTH = 8;
    public static int IS_GAME_OVER = 9;
}
