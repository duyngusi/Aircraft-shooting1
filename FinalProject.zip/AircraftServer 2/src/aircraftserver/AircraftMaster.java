package aircraftserver;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import physics.*;
import simulation.Ball;
import simulation.Boss;
import simulation.Box;
import simulation.Player;

public class AircraftMaster {

    private Box outer;
    private CopyOnWriteArrayList<Player> players;
    private Boss boss;
    private int startVote;
    private static Lock lock = new ReentrantLock();
    private static Condition newstuff = lock.newCondition();
    private static Condition newevolve = lock.newCondition();
    private static Condition wait = lock.newCondition();
    private int width;
    private int height;
    private boolean evolvestatus;

    public AircraftMaster(int width, int height) {
        this.width = width;
        this.height = height;
        outer = new Box(0, 0, width, height, false);
        players = new CopyOnWriteArrayList<Player>();
        startVote = 0;

        boss = new Boss(525, 165, 50, 100, true);
        evolvestatus = false;
    }

    public String getInners() {
        lock.lock();
        String result = "";

        try {
            while (evolvestatus == false) {
                newevolve.await();
            }

            for (Player p : players) {
                result = result + "/" + p.getBox().x + "," + p.getBox().y;
            }
            System.out.println("getInners!!");

        } catch (InterruptedException ex) {
            ex.printStackTrace();
        } finally {
            lock.unlock();
        }
        return result;
    }

    public String getBalls() {
        lock.lock();
        String result = "";
        try {
            while (evolvestatus == false) {
                newevolve.await();
            }
            for (Player p : players) {
                for (Ball ball : p.getBalls()) {
                    result = result + "/" + ball.getRay().origin.x + "," + ball.getRay().origin.y;
                }
            }

        } catch (InterruptedException ex) {
            ex.printStackTrace();
        } finally {
            lock.unlock();
        }
        System.out.println(result);
        return result;
    }

    public String getBossBalls() {
        lock.lock();
        String result = "";
        try {
            while (evolvestatus == false) {
                newevolve.await();
            }

            for (Ball ball : boss.getBalls()) {
                result = result + "/" + ball.getRay().origin.x + "," + ball.getRay().origin.y;
            }

        } catch (InterruptedException ex) {
            ex.printStackTrace();
        } finally {
            lock.unlock();
        }
        return result;
    }

    public boolean getStatus() {
        lock.lock();
        try {
            while (evolvestatus == false) {
                newevolve.await();
            }
            if (boss.getHP() <= 0) {
                return true;
            }
            for (Player p : players) {
                if (p.getHP() > 0) {
                    return false;
                }
            }
            return true;     
        } catch (InterruptedException ex) {
            ex.printStackTrace();
        } finally {
            lock.unlock();
        }

        return true;
    }

    public void recordStartVote(Player p) {
        lock.lock();
        startVote++;
        if (startVote == players.size()) {
            newstuff.signalAll();
        }
        lock.unlock();
    }

    public void addPlayer(String playername) {
        if (players.size() == 0) {
            Player newplayer = new Player(100, 50, 40, 20, true, playername);
            players.add(newplayer);
        } else if (players.size() == 1) {
            Player newplayer = new Player(100, 150, 40, 20, true, playername);
            players.add(newplayer);
        } else if (players.size() == 2) {
            Player newplayer = new Player(100, 250, 40, 20, true, playername);
            players.add(newplayer);
        } else if (players.size() == 3) {
            Player newplayer = new Player(100, 350, 40, 20, true, playername);
            players.add(newplayer);
        }
    }

    public Player findplayer(String playername) {
        for (Player p : players) {
            if (p.getPlayerName().equalsIgnoreCase(playername) == true) {
                return p;
            }
        }
        return null;
    }

    public void evolve(double time) {
        lock.lock();
        try {
            this.gameOn();
            wait.await(10, TimeUnit.MILLISECONDS);
            while (startVote < players.size()) {
                newstuff.await();
            }
            for (Ball ball : boss.getBalls()) {
                int x = 0;
                for (Player p : players) {
                    Ray newLoc = p.getBox().bounceRay(ball.getRay(), time);
                    if (newLoc != null) {
                        boss.getBalls().remove(ball);
                        p.decreaseHP();
                        if (p.getHP() <= 0) {
                            players.remove(p);
                        }
                    } else {
                        newLoc = outer.bounceRay(ball.getRay(), time);
                        if (newLoc != null) {
                            ball.setRay(newLoc);
                        } else {
                            if (x == 0){
                            ball.move(time);
                            x++;}
                        }
                    }
                }
            }
            for (Player p : players) {
                for (Ball ball : p.getBalls()) {
                    Ray newLoc = boss.getBox().bounceRay(ball.getRay(), time);
                    if (newLoc != null) {
                        p.getBalls().remove(ball);
                        boss.decreaseHP();
                    } else {
                        newLoc = outer.bounceRay(ball.getRay(), time);
                        if (newLoc != null) {
                            p.getBalls().remove(ball);
                        } else {
                            ball.move(time);
                        }
                    }
                }
            }
            evolvestatus = true;
            newevolve.signalAll();
        } catch (InterruptedException ex) {
            ex.printStackTrace();
        } finally {
            lock.unlock();
        }
    }

    public int getBossHealth() {
        lock.lock();
        int result = 0;
        try {
            while (evolvestatus == false) {
                newevolve.await();
            }
            result = boss.getHP();
        } catch (InterruptedException ex) {
            ex.printStackTrace();
        } finally {
            lock.unlock();
        }
        return result;
    }

    public String getPlayerHealth() {
        lock.lock();
        String str = "";
        try {
            while (evolvestatus == false) {
                newevolve.await();
            }
            for (Player player : players) {
                str = str + player.getPlayerName() + ":" + player.getHP() + "  ";
            }
        } catch (InterruptedException ex) {
            ex.printStackTrace();
        } finally {
            lock.unlock();
        }
        return str;
    }

    public void moveInner(Player p, int deltaX, int deltaY) {
        /** Your original logic had a problem caused by the fact that
         *  dead players can still send move requests. To prevent
         *  problems caused by this I added the next line of code: **/
        if(p == null) { return; }
        lock.lock();
        try {
            int dX = deltaX;
            int dY = deltaY;
            if (p.getBox().x + deltaX < 0) {
                dX = -p.getBox().x;
            }
            if (p.getBox().x + p.getBox().width + deltaX > outer.width) {
                dX = outer.width - p.getBox().width - p.getBox().x;
            }

            if (p.getBox().y + deltaY < 0) {
                dY = -p.getBox().y;
            }
            if (p.getBox().y + p.getBox().height + deltaY > outer.height) {
                dY = outer.height - p.getBox().height - p.getBox().y;
            }

            p.getBox().move(dX, dY);
            //Necessary?
            for (Ball ball : boss.getBalls()) {
                if (p.getBox().contains(ball.getRay().origin)) {
                    // If we have discovered that the box has just jumped on top of
                    // the ball, we nudge them apart until the box no longer
                    // contains the ball.
                    boss.getBalls().remove(ball);
                    p.decreaseHP();
                }
            }
        } finally {
            lock.unlock();
        }
    }

    private void gameOn() {
        for (Player p : players) {
            p.gameOn();
        }
        this.boss.gameOn();
    }
}
