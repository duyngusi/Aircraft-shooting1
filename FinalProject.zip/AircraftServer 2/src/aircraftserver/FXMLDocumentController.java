/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aircraftserver;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.URL;
import java.util.Date;
import java.util.ResourceBundle;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TextArea;

/**
 *
 * @author Joe Gregg
 */
public class FXMLDocumentController implements Initializable {

    @FXML
    private TextArea textArea;

    private int clientNo = 0;
    private AircraftMaster aMaster;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        aMaster = new AircraftMaster(600, 430);
        new Thread(() -> {
            try {
                // Create a server socket
                ServerSocket serverSocket = new ServerSocket(8000);

                while (true) {
                    // Listen for a new connection request
                    Socket socket = serverSocket.accept();

                    // Increment clientNo
                    clientNo++;

                    Platform.runLater(() -> {
                        // Display the client number
                        textArea.appendText("Starting thread for client " + clientNo
                                + " at " + new Date() + '\n');
                    });

                    // Create and start a new thread for the connection
                    new Thread(new HandleAClient(socket, aMaster, textArea)).start();
                }
            } catch (IOException ex) {
                System.err.println(ex);
            }
        }).start();
    }

}

class HandleAClient implements Runnable, aircraft.AircraftConstants {

    private Socket socket; // A connected socket
    // Reference to shared transcript
    private TextArea textArea;
    private String handle;
    private AircraftMaster aMaster;
    private int players;
    private int start;
    private boolean OK;

    public HandleAClient(Socket socket, AircraftMaster aMaster, TextArea textArea) {
        this.socket = socket;
        this.aMaster = aMaster;
        this.textArea = textArea;
        this.players = 0;
        this.start = 0;
        this.OK = false;
    }
    
    public void run() {
        try {
// Create reading and writing streams
            BufferedReader inputFromClient = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            PrintWriter outputToClient = new PrintWriter(socket.getOutputStream());
            // Continuously serve the client
            while (true) {

                // Receive request code from the client
                try {
                    int request = Integer.parseInt(inputFromClient.readLine());
                    System.out.println("Request: " + request);
                    // Process request
                    switch (request) {
                        case SEND_HANDLE: {
                            handle = inputFromClient.readLine();
                            System.out.println(handle);
                            aMaster.addPlayer(handle);
                            players++;
                            OK = true;
                            break;
                        }
                        case MOVE_AIRCRAFT: {
                            handle = inputFromClient.readLine();
                            String command = inputFromClient.readLine();
                            if (command.equalsIgnoreCase("up")) {
                                aMaster.moveInner(aMaster.findplayer(handle), 0, -3);
                            }
                            if (command.equalsIgnoreCase("down")) {
                                aMaster.moveInner(aMaster.findplayer(handle), 0, 3);
                            }
                            if (command.equalsIgnoreCase("left")) {
                                aMaster.moveInner(aMaster.findplayer(handle), -3, 0);
                            }
                            if (command.equalsIgnoreCase("right")) {
                                aMaster.moveInner(aMaster.findplayer(handle), 3, 0);
                            }
                            break;
                        }

                        case GET_PLAYER_BALLS: {
                            outputToClient.println(aMaster.getBalls());
                            System.out.println(aMaster.getBalls());
                            outputToClient.flush();
                            break;
                        }
                        case GET_PLAYER_AIRCRAFTS: {
                            outputToClient.println(aMaster.getInners());
                            System.out.println(aMaster.getInners());
                            outputToClient.flush();
                            break;
                        }
                        case GET_BOSS_BALLS: {
                            outputToClient.println(aMaster.getBossBalls());
                            System.out.println(aMaster.getBossBalls());
                            outputToClient.flush();
                            break;
                        }
                        case GET_BOSS_HEALTH: {
                            outputToClient.println(aMaster.getBossHealth());
                            outputToClient.flush();
                            break;
                        }
                        case GET_PLAYER_HEALTH: {
                            outputToClient.println(aMaster.getPlayerHealth());
                            outputToClient.flush();
                            break;
                        }
                        case IS_GAME_OVER: {
                            outputToClient.println(aMaster.getStatus());
                            outputToClient.flush();
                            break;
                        }
                        case RECORD_START_VOTE: {
                            handle = inputFromClient.readLine();
                            aMaster.recordStartVote(aMaster.findplayer(handle));
                            start++;
                            break;
                        }
                    }
                    if (start >= players && OK == true) {
                        
                        aMaster.evolve(2.0);
                        
                        System.out.println("evolve");
                    }
                    Thread.sleep(1);
                } catch (InterruptedException ex) {
                    ex.printStackTrace();
                }
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }
}
