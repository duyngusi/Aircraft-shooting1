/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package simulation;

import java.util.concurrent.CopyOnWriteArrayList;

/**
 *
 * @author hoang
 */
public class Boss {

    private Box bossBox;
    private CopyOnWriteArrayList<Ball> balls;
    private int HP;
    private boolean play = false;

    public Boss(int x, int y, int width, int height, boolean outward) {
        bossBox = new Box(x, y, width, height, outward);
        balls = new CopyOnWriteArrayList<Ball>();
        HP = 100;
        new Thread(() -> {
            while (true) {
                if (play) {
                    this.GenerateBall();
                }
                try {
                    Thread.sleep(3000);
                } catch (InterruptedException ex) {

                }
            }
        }).start();
    }

    public void GenerateBall() {
        for (int i = 0; i < 3; i++) {
            int dy = (int) Math.floor(5 * Math.random()) - 2;
            int dx = (int) -(Math.sqrt(2 - dy*dy/2) + 1);
            Ball newball = new Ball(bossBox.x, bossBox.y + bossBox.height / 2, dx, dy);
            balls.add(newball);
        }
    }

    public void gameOn() {
        play = true;
    }

    public Box getBox() {
        return bossBox;
    }

    public CopyOnWriteArrayList<Ball> getBalls() {
        return balls;
    }

    public int getHP() {
        return HP;
    }

    public void decreaseHP() {
        HP = HP - 2;
    }

    public void deleteBall(Ball x) {
        balls.remove(x);
    }
}
