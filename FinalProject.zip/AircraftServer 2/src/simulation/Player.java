package simulation;

import java.util.concurrent.CopyOnWriteArrayList;

public class Player {

    private Box inner;
    private CopyOnWriteArrayList<Ball> balls;
    private String name;
    private int HP;
    private boolean play = false;

    public Player(int x, int y, int width, int height, boolean outward, String name) {
        inner = new Box(x, y, width, height, outward);
        balls = new CopyOnWriteArrayList<Ball>();
        HP = 3;
        this.name = name;
        new Thread(() -> {
            while (true) {
                if (play) {
                    this.GenerateBall();
                }
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException ex) {

                }
            }
        }).start();
    }

    public void GenerateBall() {
        Ball newball = new Ball(inner.x + inner.width, inner.y + inner.height / 2, 1, 0);
        balls.add(newball);
    }

    public void gameOn() {
        play = true;
    }

    public Box getBox() {
        return inner;
    }

    public CopyOnWriteArrayList<Ball> getBalls() {
        return balls;
    }

    public void deleteBall(Ball x) {
        balls.remove(x);
    }

    public String getPlayerName() {
        return name;
    }

    public void decreaseHP() {
        HP = HP - 1;
    }

    public int getHP() {
        return HP;
    }
}
