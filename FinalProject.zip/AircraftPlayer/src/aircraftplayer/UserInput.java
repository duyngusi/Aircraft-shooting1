/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aircraftplayer;

import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

/**
 *
 * @author Chimeras96
 */
public class UserInput {

    private String input;
    private static Lock lock = new ReentrantLock();
    private static Condition answered = lock.newCondition();

    public UserInput() {
        input = " ";
    }

    public void setInput(String input) {
        this.input = input;
        this.unblock();
    }

    public String getPlayerAnswer() {
        lock.lock();
        try {
            if (input == " ") {
                answered.await(10, TimeUnit.SECONDS);
            }
        } catch (InterruptedException ex) {
            ex.printStackTrace();
        }
        lock.unlock();
        return input;
    }

    public void unblock() {
        lock.lock();
        if (input != " ") {
            answered.signalAll();
        }
        lock.unlock();
    }
}