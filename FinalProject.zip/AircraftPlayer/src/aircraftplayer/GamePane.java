/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aircraftplayer;

import java.util.ArrayList;
import java.util.List;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Rectangle;
import javafx.scene.shape.Shape;

/**
 *
 * @author Chimeras96
 */
class GamePane extends Pane {
    List<Shape> shapes;

    public GamePane(int w, int h) {
        this.setHeight(h);
        this.setWidth(w);
        shapes = new ArrayList<Shape>();
    }

    public void updateShapes(String playerAircrafts, String playerBalls, String bossBalls) {
      
        shapes.clear();
        this.setPlayerBalls(playerBalls);
        this.setBossBalls(bossBalls);
        this.setPlayerAircrafts(playerAircrafts);
        this.createBoss();
        this.setShapes(shapes);
    }

    public void setShapes(List<Shape> newShapes) {
        this.getChildren().clear();
        this.getChildren().addAll(newShapes);
    }

    private void setPlayerBalls(String pBalls) {
        String[] str = pBalls.substring(1).split("/");
        for (int i = 0; i < str.length; i++)
            System.out.println(str[i]);
        for (int i = 0; i < str.length; i++) {
            String[] position = str[i].split(",");
            Circle c = new Circle(Double.parseDouble(position[0]), Double.parseDouble(position[1]), 4);
            c.setFill(Color.RED);
            shapes.add(c);
        }
    }

    private void setBossBalls(String bBalls) {
        String[] str = bBalls.substring(1).split("/");
        for (int i = 0; i < str.length; i++) {
            String[] position = str[i].split(",");
            Circle c = new Circle(Double.parseDouble(position[0]), Double.parseDouble(position[1]), 4);
            c.setFill(Color.BLUE);
            shapes.add(c);
        }
    }

    private void setPlayerAircrafts(String pAircrafts) {
        String[] str = pAircrafts.substring(1).split("/");
        for (int i = 0; i < str.length; i++) {
            String[] position = str[i].split(",");
            Rectangle r = new Rectangle(Double.parseDouble(position[0]), Double.parseDouble(position[1]), 40, 20);
            r.setFill(Color.WHITE);
            r.setStroke(Color.BLACK);
            shapes.add(r);
        }
    }

    private void createBoss() {
        Rectangle r = new Rectangle(525, 165, 50, 100);
        r.setFill(Color.BLUE);
        r.setStroke(Color.BLACK);
        shapes.add(r);
    }
}
