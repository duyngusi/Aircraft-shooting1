/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aircraftplayer;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import javafx.application.Platform;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;

/**
 *
 * @author Chimeras96
 */
public class AircraftGateway implements aircraft.AircraftConstants {

    private PrintWriter outputToServer;
    private BufferedReader inputFromServer;
    private Label label;

    // Establish the connection to the server.
    public AircraftGateway(Label label) {
        this.label = label;
        try {
            // Create a socket to connect to the server
            Socket socket = new Socket("localhost", 8000);

            // Create an output stream to send data to the server
            outputToServer = new PrintWriter(socket.getOutputStream());

            // Create an input stream to read data from the server
            inputFromServer = new BufferedReader(new InputStreamReader(socket.getInputStream()));

        } catch (IOException ex) {
            Platform.runLater(() -> label.setText("Exception in gateway constructor: " + ex.toString() + "\n"));
        }
    }

    public synchronized void setPlayer(String playerName) {
        outputToServer.println(SEND_HANDLE);
        outputToServer.println(playerName);
        outputToServer.flush();
    }

    public synchronized void recordStartVote(String playerName) {
        outputToServer.println(RECORD_START_VOTE);
        outputToServer.println(playerName);
        outputToServer.flush();
    }

    public synchronized boolean isGameOver() {
        String n = "";
        outputToServer.println(IS_GAME_OVER);
        outputToServer.flush();
        try {
            n = inputFromServer.readLine();
        } catch (IOException ex) {
            Platform.runLater(() -> label.setText("Error in isGameOver: " + ex.toString() + "\n"));
        }
        if (n.equalsIgnoreCase("true")) {
            return true;
        }
        return false;
    }

    
    public synchronized void movePlayer(String playerName, String move) {
        outputToServer.println(MOVE_AIRCRAFT);
        outputToServer.println(playerName);
        outputToServer.println(move);
        outputToServer.flush();
    }

    public synchronized String getPlayerBalls() {
        outputToServer.println(GET_PLAYER_BALLS);
        outputToServer.flush();
        try {
            return inputFromServer.readLine();
        } catch (IOException ex) {
            Platform.runLater(() -> label.setText("Error in getPlayerBalls: " + ex.toString() + "\n"));
        }
        return null;
    }

    public synchronized String getPlayerAircrafts() {
        outputToServer.println(GET_PLAYER_AIRCRAFTS);
        outputToServer.flush();
        try {
            return inputFromServer.readLine();
        } catch (IOException ex) {
            Platform.runLater(() -> label.setText("Error in getPlayerAircrafts: " + ex.toString() + "\n"));
        }
        return null;
    }

    public synchronized String getBossBalls() {
        outputToServer.println(GET_BOSS_BALLS);
        outputToServer.flush();
        try {
            return inputFromServer.readLine();
        } catch (IOException ex) {
            Platform.runLater(() -> label.setText("Error in getBossBalls: " + ex.toString() + "\n"));
        }
        return null;
    }

    public synchronized String getBossHealth() {
        outputToServer.println(GET_BOSS_HEALTH);
        outputToServer.flush();
        try {
            return inputFromServer.readLine();
        } catch (IOException ex) {
            Platform.runLater(() -> label.setText("Error in getBossHealth: " + ex.toString() + "\n"));
        }
        return null;
    }

    synchronized String getPlayerHealth() {
        outputToServer.println(GET_PLAYER_HEALTH);
        outputToServer.flush();
        try {
            return inputFromServer.readLine();
        } catch (IOException ex) {
            Platform.runLater(() -> label.setText("Error in getPlayerHealth: " + ex.toString() + "\n"));
        }
        return null;
    }
}
