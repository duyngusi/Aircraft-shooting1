/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aircraftplayer;

import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.TextInputDialog;
import javafx.scene.layout.BorderPane;

/**
 *
 * @author Chimeras96
 */
public class FXMLDocumentController implements Initializable {

    private GamePane gamePane;
    private AircraftGateway gateway;
    private String playerName;
    private UserInput input;

    @FXML
    private Label label;
    @FXML
    private BorderPane parentPane;
    @FXML
    private Label playersHealth;
    @FXML
    private ProgressBar bossHealth;

    @FXML
    private void start(ActionEvent event) {
        input.setInput("s");
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        input = new UserInput();
        gateway = new AircraftGateway(label);
        gamePane = new GamePane(600, 400);
        parentPane.setOnKeyPressed(e -> {
            switch (e.getCode()) {
                case DOWN:
                    gateway.movePlayer(playerName, "DOWN");
                    break;
                case UP:
                    gateway.movePlayer(playerName, "UP");
                    break;
                case LEFT:
                    gateway.movePlayer(playerName, "LEFT");
                    break;
                case RIGHT:
                    gateway.movePlayer(playerName, "RIGHT");
                    break;
            }
        });
        gamePane.requestFocus();
        parentPane.setCenter(gamePane);
        System.out.println("Start game.");

        // Put up a dialog to get a handle from the user
        TextInputDialog dialog = new TextInputDialog();
        dialog.setTitle("Start Game");
        dialog.setHeaderText(null);
        dialog.setContentText("Enter your name:");

        Optional<String> result = dialog.showAndWait();
        result.ifPresent(name -> playerName = name);

        new Thread(() -> {
            gateway.setPlayer(playerName);
            System.out.println(playerName);
            label.setText("Press START to begin.");
            String startVote = input.getPlayerAnswer();
            while (!startVote.equals("s")) {
                startVote = input.getPlayerAnswer();
            }
            Platform.runLater(() -> {
                label.setText("Waiting for other players...");
            });
            gateway.recordStartVote(playerName);
            System.out.println("Enter the loop.");
            while (gateway.isGameOver() == false) {
                System.out.println("Getting stuffs now!");
                String playerAircrafts = gateway.getPlayerAircrafts();
                String playerBalls = gateway.getPlayerBalls();
                String bossBalls = gateway.getBossBalls();
                double bossHP = Double.parseDouble(gateway.getBossHealth()) / 100;
                System.out.println(bossHP);
                System.out.println("Done getting stuffs.");
                Platform.runLater(() -> {
                    System.out.println("Update GUI.");
                    bossHealth.setProgress(bossHP);
                    playersHealth.setText(gateway.getPlayerHealth());
                    label.setText(" ");
                    gamePane.updateShapes(playerAircrafts, playerBalls, bossBalls);
                });
                try {
                    Thread.sleep(1);
                } catch (InterruptedException ex) {

                }
            }
            if (Integer.parseInt(gateway.getBossHealth()) == 0) {
                Platform.runLater(() -> label.setText("Game over! You won."));
            } else {
                Platform.runLater(() -> label.setText("Game over! You lost."));
            }
        }).start();
    }
}
