/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aircraft;

/**
 *
 * @author Chimeras96
 */
public interface AircraftConstants {
    public static int SEND_HANDLE = 1;
    public static int RECORD_START_VOTE = 2;
    public static int MOVE_AIRCRAFT = 3;
    public static int GET_PLAYER_BALLS = 4;
    public static int GET_PLAYER_AIRCRAFTS = 5;
    public static int GET_BOSS_BALLS = 6;
    public static int GET_BOSS_HEALTH = 7;
    public static int GET_PLAYER_HEALTH = 8;
    public static int IS_GAME_OVER = 9;
}
